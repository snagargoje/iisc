function [ model ] = max_lhood_gauss_est_param( X, Yx)
% Input  :  X - training instances, Yx - training labels
% Output :  model - contains the estimated parameters of each
%           Gaussian (means and covariance matrices)

    % Add code here for parameter estimation

    
    % Change the line below and set the variable model appropriately.
    model = [];
end

