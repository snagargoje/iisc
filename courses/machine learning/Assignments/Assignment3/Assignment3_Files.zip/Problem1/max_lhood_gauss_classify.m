function [ pred ] = max_lhood_gauss_classify( model, T )
% Input  : model - is the model learnt using max_lhood_gauss_est_param.m.
%          T - is the test data instances (one per row).
% Output : pred - is a vector of predicted labels (one per row)

    % Add code here for classification


    % Change the line below and set the predictions appropriately.
    pred = zeros(size(T,1),1);
end

