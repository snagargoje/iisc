The contents of this folder are as follows:

data_digit_10class
------------------

  train            7291x256           
  test             2007x256           
  label_test       2007x1                   
  label_train      7291x1                    
         


Each image is a 256*1 vector. Refer to assignment 1 for further details about accessing these images in matlab.


multiclass_error.m
-------------------------

This file computes the misclassification error for the multiclass classification problem.

