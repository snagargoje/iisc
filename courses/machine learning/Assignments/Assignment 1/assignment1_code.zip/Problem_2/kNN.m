function pred = kNN(X_train,y_train,k,x_test) 
%The function performs k-nearest neighbour classification.
% X_train - Input training data matrix (size m*n where m is 		  the number of datapoints and n is the dimension of 		  each datapoint)
% y_train - Input training data labels corresponding to X_train
% k       - Number of neighbours to consider
% x_test  - Test instance


% REMOVE THE FOLLOWING LINE AND IMPLEMENT YOUR CODE HERE
pred = 1;
end

