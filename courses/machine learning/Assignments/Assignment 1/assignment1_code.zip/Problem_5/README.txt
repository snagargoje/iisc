README - Problem 5
------------------


In this directory, the following files are provided.

 1. SVM_learner.m  -  This function is used to learn a SVM model given training data and SVM parameters (C,d)
 2. SVM_classifier.m - This function is used to predict the label of a new test instance based on the model learnt using SVM_learner.m
 2. decision_boundary_SVM.m - This function plots the decision boundary given the training samples with respect to the SVM classifier learnt using SVM_learner.m
 