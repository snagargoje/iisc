function[labels] = SVM_classifier(testdata, model)
    % INPUT
    % testdata - m X n matrix of the test data samples
    % model    - The SVM model structure returned by SVM_learner
    
    % OUTPUT
    % labels - The predicted labels
    
    % Change the code below
    labels = ones(size(testdata, 1), 1);
end