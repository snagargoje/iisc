function[model] = SVM_learner(traindata, trainlabels, C, kerneltype, d)
    % INPUT : 
    % traindata   - m X n matrix, where m is the number of training points
    % trainlabels - m X 1 vector of training labels for the training data
    % C           - SVM regularization parameter (positive real number)
    % kerneltype  - one of the strings 'linear', 'poly', 'rbf'
    %               corresponding to the linear, polynomial, and gaussian kernels
    %               respectively.
    % d           - Integer parameter indicating the degree of the
    %               polynomial for polynomial kernel, or the width
    %               parameter for the gaussian kernel. Not used for the
    %               linear kernel.
    
    % OUTPUT
    % returns the structure 'model' which has the following fields, in
    % addition to the training data/parameters.(You can choose to add more
    % fields to this structure before saving if needed by your implementation)
    
    
    % alphas      - m X 1 vector of support vector coefficients
    % b           - SVM bias
    % objective   - Final optimal objective value of the SVM solver
    % support_vectors - the subset of training data, which are the support
    % vectors
    
    % default code below, remove that and write the code for solving the
    % SVM formulation using quadprog function
    % The model is saved into model.mat, which will be read in the
    % SVM_classifier routine
    
    b = 0;
    objective = 0;
    alphas = repmat(0, size(traindata, 1), 1);
    
    model.b = b;
    model.objective = objective;
    model.alphas = alphas; 
    model.kerneltype = kerneltype;
    model.d = d;
    model.C = C;
    model.traindata = traindata;
    mode.trainlabels = trainlabels;
    model.support_vectors = traindata;
    save('SVM_model.mat', 'model');
end